from django.apps import AppConfig


class NotifConfig(AppConfig):
    name = 'notif'
